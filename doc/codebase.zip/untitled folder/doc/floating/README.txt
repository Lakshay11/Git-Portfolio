A Pen created at CodePen.io. You can find this one at https://codepen.io/RSH87/pen/grdJKQ.

 Just a simple case study, with SCSS, showing a example on how to achieve some kind of 3d effect using blur and perspective.